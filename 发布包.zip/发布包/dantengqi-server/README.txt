蛋疼棋 · 联机服务器部署包
================================

里面是什么
----------
server/   联机服务端（Node + ws）
src/      规则引擎（服务端直接复用）
dist/     打包好的游戏页面
deploy/   安装脚本与部署说明

部署（在服务器上，需要 root）
----------------------------
  cd dantengqi-server
  sudo bash deploy/install.sh

默认端口 6657；想换端口：
  sudo PORT=8080 bash deploy/install.sh

装好后打开：
  http://<服务器公网IP>:6657/

验证本机是否正常：
  curl http://127.0.0.1:6657/health
  应返回 {"ok":true}

注意事项
--------
1. 云控制台的安全组要放行 6657/tcp，否则外网打不开；
2. 需要能访问外网（脚本要装 Node.js 20）；
3. 服务用 systemd 托管，命令：
     systemctl status danteng
     journalctl -u danteng -f
4. 房间只存内存，重启服务会丢失进行中的对局。

详细说明见 deploy/README.md。
